$cfg['Servers'][$i]['user'] = 'root'; // Your MySQL username
$cfg['Servers'][$i]['password'] = ''; // Your MySQL password


